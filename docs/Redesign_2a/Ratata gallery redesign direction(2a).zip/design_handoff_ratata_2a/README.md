# Handoff: ratata gallery — Homepage "Zwei Spuren / Invers" (option 2a)

## Overview
A redesign of the ratata gallery homepage (https://ratata.gallery). ratata is a Frankfurt gallery for
digital art: it curates shows, produces exhibitions at fairs, and builds the technology behind them.
The design expresses that split literally: the page runs as **two parallel tracks** — an *art* track on
gallery-white and a *code/technology* track on near-black — and adds a **SIGNAL** section that
aggregates the gallery's own Instagram/X posts alongside third-party mentions.

Primary audiences, in order: institutions/brands hiring production, press, collectors, fair organisers.
Bilingual: German is the default, English is a switch in the header.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing intended
look, content and behaviour. They are **not production code to copy**. The task is to recreate the
design in the target codebase's environment and patterns. The live site is a **Next.js** app
(`/_next/image` URLs, `/projects/[slug]` routes, DE/EN routing), so the natural target is that existing
Next.js project: build this as the homepage, reusing its data layer for projects/exhibitions, its
`next/image` pipeline, and its i18n mechanism.

- `Ratata Directions.dc.html` — the prototype. It contains **four** directions on one canvas.
  **Only build `2a`** (the first block, id `2a`, labelled "ZWEI SPUREN / INVERS"). 1a/1b/1c below it
  are rejected alternatives kept for reference.
- `support.js` — runtime needed to open the prototype in a browser. Keep both files side by side and
  open the `.dc.html` file directly.
- All content strings, project lists and image URLs live in the `<script data-dc-script>` logic class
  at the bottom of the `.dc.html` file (`dict`, `works`, `exhData`, `prodData`, `partnerFiles`,
  `feedPosts`, `feedMentions`). Read those arrays as the content spec.

## Fidelity
**High-fidelity.** Colors, type, spacing and hover states are final and specified below; match them.
Two caveats:
1. The prototype is a **desktop-only canvas at 1440px**. No mobile/tablet layouts were designed —
   see *Responsive behaviour* for the intended reductions, but confirm breakpoint decisions with the
   designer before shipping.
2. The wordmark is set as **live type** ("ratata" in Archivo 900) because the real logo file was not
   available. Swap in ratata's actual logo SVG.

---

## Screen: Homepage
One long scrolling page, 1440px design width, content edge padding **40px**, sections separated by
`1px solid #111112` rules. Section stack, top to bottom:

### 1. Header / nav
- Height **76px**, `border-bottom: 1px solid #111112`, background `#f6f5f2`, padding `0 40px`.
- Layout: `flex; align-items:center; justify-content:space-between`.
- Left: wordmark `ratata` — Archivo 900, **26px**, `letter-spacing:-0.05em`, `#111112`.
- Center: nav links — JetBrains Mono 400, **11px**, `letter-spacing:0.14em`, uppercase, `gap:28px`.
  Items (DE / EN): Ausstellungen / Exhibitions · Produktion / Production · Leistungen / Services ·
  TezCon Europe · Über uns / About. Hover: color → `#c2410c`.
- Right: DE / EN buttons — same mono 11px, `padding:5px 9px`, `border:1px solid #c9c6be`,
  transparent background, `gap:2px`. Active language `opacity:1`, inactive `opacity:0.4`.
- Sticky is **not** specified; make it sticky only if the codebase already does so elsewhere.

### 2. Hero — two tracks
`display:grid; grid-template-columns:1.35fr 1fr`.

**Left cell (art track)** — background `#f6f5f2`, `padding:48px 44px`, `border-right:1px solid #111112`.
- Kicker: `01 — Kunst` / `01 — Art`. Mono 11px, `letter-spacing:0.16em`, `#c2410c`, margin-bottom 16px.
- Headline, two lines (`<br>`): DE "Digitale Kunst" / "braucht echte Wände." — EN "Digital art" /
  "needs real walls." Archivo **900, 104px**, `line-height:0.86`, `letter-spacing:-0.05em`, uppercase.
- Framed artwork card, `margin-top:36px`: background `#fff`, `padding:22px`, `box-shadow:0 1px 0 #e2dfd7`
  (a matted print, not a rounded card — **no border-radius anywhere in this design**).
  Image `aspect-ratio:16/10; object-fit:cover`.
  Caption row below image, `margin-top:12px`, mono 11px, space-between:
  left `Deposed 004 — Mario Klingemann` (`#111112`), right `WHAT HOT SH!T · 2021` (`#6d6a63`).

**Right cell (code track)** — background `#111112`, color `#f6f5f2`, `padding:48px 40px`,
`flex column; justify-content:space-between`.
- Kicker `02 — Technik` / `02 — Code`, mono 11px, `letter-spacing:0.16em`, `#ff7a2f`.
- Lead paragraph, Archivo 400 **20px**, `line-height:1.45`, `text-wrap:pretty`:
  DE "ratata kuratiert digitale Kunst, produziert Ausstellungen auf internationalen Messen und baut die
  Technik, die sie zum Laufen bringt. Frankfurt am Main, seit 2019."
  EN "ratata curates digital art, produces exhibitions at international fairs, and builds the
  technology that makes them run. Frankfurt am Main, since 2019."
- Two definition blocks, each `border-top:1px solid #35353a; padding-top:12px`, mono 12px,
  `line-height:1.7`; label `#8a8a86` `letter-spacing:0.1em`, value `#f6f5f2`:
  - Kunst / Art — "Kuration, Künstler:innen, Ausstellungen, Räume." / "Curation, artists, exhibitions, rooms."
  - Technik / Code — "Displays, LED, Projektion, interaktive Systeme, Smart Contracts, Minting." /
    "Displays, LED, projection, interactive systems, smart contracts, minting."
- CTA button, `align-self:start`: background `#ff7a2f`, color `#111112`, `padding:15px 24px`,
  mono **12px 700**, `letter-spacing:0.14em`, uppercase, label "Projekt anfragen →" /
  "Start a project →". Hover: background `#f6f5f2`. Links to the contact/enquiry route.

### 3. Stats strip
`grid-template-columns:repeat(5,1fr)`, `border-top`/`border-bottom: 1px solid #111112`,
each cell `padding:24px`, `border-right:1px solid #dedbd3`.
Number: Archivo 900 **52px**, `line-height:1`, `letter-spacing:-0.04em`.
Label: mono 11px, uppercase, `letter-spacing:0.12em`, `#6d6a63`, `margin-top:6px`.

| Number | DE label | EN label | Source |
|---|---|---|---|
| 25 | Projekte | Projects | 13 exhibitions + 12 productions |
| 13 | Ausstellungen | Exhibitions | /exhibitions count |
| 12 | Produktionen | Productions | /production count |
| 6 | Städte | Cities | Frankfurt, Berlin, Mainz, Valencia, Lisbon, Galicia |
| 40+ | Künstler:innen | Artists | across the archive |

**Wire these to real counts** from the CMS/data layer rather than hardcoding.

### 4. SIGNAL — social feed *(new section, does not exist on the live site)*
Section wrapper `border-bottom:1px solid #111112`.

Header row `padding:34px 40px 18px`, space-between, baseline-aligned:
- Title "Signal", Archivo 900 **44px**, uppercase, `letter-spacing:-0.04em`.
- Beside it (`gap:16px`), mono 11px `letter-spacing:0.14em` `#c2410c`: a blinking `●`
  (1.4s steps(1) infinite) + "Live aus Instagram & X" / "Live from Instagram & X".
- Right: disclosure chip — mono 11.5px, `#111112` on `#ffd9c2`, `padding:5px 9px`:
  "Beispieldaten — Feed wird zur Laufzeit geladen" / "Sample data — feed loads at runtime".
  **Remove this chip once the feed is wired to real data.**

Body `grid-template-columns:1.4fr 1fr`.

**Left: own posts** — `border-right:1px solid #111112`, `padding:0 40px 34px`.
Column heading: mono 11px `letter-spacing:0.14em` `#6d6a63`,
`border-bottom:1px solid #dedbd3; padding-bottom:10px; margin-bottom:18px`:
"Von ratata · @ratata.gallery · @ratata_artcode" / "From ratata · …".
Cards: `grid-template-columns:1fr 1fr; gap:18px`. Each card `background:#fff`,
`border:1px solid #e6e3db`; hover `border-color:#111112`. Image `aspect-ratio:4/3; object-fit:cover`,
`transition:transform .5s`, hover `scale(1.04)`. Text block `padding:12px 14px 14px`:
meta row mono 10.5px — platform+handle `#c2410c`, relative time `#9b978e`;
caption Archivo 15px `line-height:1.4` `margin-top:8px`.

**Right: mentions** — `background:#111112`, color `#f6f5f2`, `padding:22px 40px 34px`.
Heading mono 11px `#d4d2cc`, `border-bottom:1px solid #35353a; padding-bottom:10px`:
"Erwähnungen · #ratata #tezcon · " + the disclosure text in `#ff7a2f`.
Rows: `padding:13px 0; border-bottom:1px solid #26262a`; hover color `#ff7a2f`.
Meta row mono 10.5px — handle `#ff7a2f`, time `#8a8a86`; body Archivo 15px `line-height:1.4`.

**Data / feasibility — read before building.** All feed content in the prototype is placeholder.
The handles in the mentions column are deliberately fictional (`@collector_0x`, `@kurator.ffm`,
`@artist_berlin`, `@tezos_dev`, `@venue.frankfurt`, `@press_desk`) and their text literally says
"loads from the API at runtime" — **never ship invented quotes attributed to real accounts**
(ratata's real partners and artists are listed on /about).
- *Own posts* are straightforward: Instagram Graph API (requires an Instagram Business/Creator
  account linked to a Facebook page) for `@ratata.gallery`; X API v2 user-timeline for
  `@ratata_artcode`. Cache server-side (revalidate ~15–60 min); never call from the client with
  a live token.
- *Mentions* are the expensive half: X mention/search endpoints need a paid tier, and Instagram
  offers no public mention search. Options: (a) paid X tier + `@ratata` mention query, (b) a
  moderated table where the team pastes mention URLs and the server hydrates oEmbed, (c) drop the
  mentions column and run the section single-column with own posts only.
- Empty/failure state: hide the whole SIGNAL section rather than render an empty grid.

### 5. Two tracks — archive & capability
`grid-template-columns:1fr 1fr`.

**Left column (art track, `#f6f5f2`, `border-right:1px solid #111112`)**
- "Ausstellungen" / "Exhibitions": Archivo 900 **38px** uppercase `letter-spacing:-0.03em`,
  `padding:34px 40px 16px`; right-aligned count mono 11px `#6d6a63` — `5 / 13 Projekte`
  (list shows 5 of 13; keep the ratio honest or link to the full archive).
- Exhibition rows: `grid-template-columns:132px 1fr; gap:20px; padding:16px 40px;
  border-top:1px solid #dedbd3`; hover background `#fff`.
  Thumb 132×88 `object-fit:cover` on `#e9e6de`. Title Archivo 600 **22px** `line-height:1.15`;
  meta mono 11px `#6d6a63` `margin-top:8px`.
  Rows link to `/projects/<slug>`.
- Archive link: "Archiv mit Filtern öffnen →" / "Open the filtered archive →", mono 12px `#c2410c`,
  `padding:20px 40px; border-top:1px solid #dedbd3` → `/exhibitions`.
- "Gezeigte Arbeiten" / "Works shown" heading (same 38px style), `border-top:1px solid #111112`.
- Works grid: `repeat(3,1fr); gap:14px; padding:0 40px 36px`. Each: `background:#fff; padding:10px;
  border:1px solid #e6e3db`, square image `object-fit:cover`, hover `scale(1.05)` over `.5s`;
  artist name mono 10px `#6d6a63` `margin-top:8px`.

**Right column (code track, `#111112`, color `#f6f5f2`)**
- "Was wir liefern" / "What we deliver", 38px uppercase. Three rows, each
  `padding:18px 40px; border-top:1px solid #26262a; grid-template-columns:28px 1fr; gap:18px`;
  index (`01`–`03`) mono 11px `#ff7a2f`; title Archivo 600 21px; body Archivo 15px
  `line-height:1.5` `#a9a7a1`:
  1. **Kuration & Programm** / *Curation & programme* — "Konzept, Künstlerauswahl, Texte und
     Werkbeschreibungen — vom Einzelabend bis zum Messestand."
  2. **Ausstellungsproduktion** / *Exhibition production* — "Aufbau, Displays, LED-Wände, Projektion,
     Ton, Logistik und Betreuung vor Ort."
  3. **Technik & Plattformen** / *Tech & platforms* — "Interaktive Installationen, Smart Contracts,
     Minting-Flows und eigene Web-Plattformen."
  (This section is **new** — it does not exist on the live site. Copy needs sign-off from Phil.)
- "Produktion" / "Production" heading + count `12 Projekte`. Rows:
  `grid-template-columns:26px 1fr auto; gap:16px; padding:11px 40px; border-top:1px solid #26262a`;
  index mono 12px `#8a8a86`, title Archivo 500 17px, meta mono 12px `opacity:.7`.
  Hover **inverts the row**: background `#f6f5f2`, color `#111112`.
  All 12 items, in order: 8scribo (2022) · NFT Show Europe 2023 — ratata booth (Valencia 2023) ·
  Collective Voice ID (2022–2024) · NFC Summit Lisbon (Lisbon 2025) · UAI — AI Startup Event Hessen
  (Frankfurt 2022) · Deutsche Bank AI & Art Night (Frankfurt 2023) · InfiniteInk (2025) ·
  Tesserart (2024) · UAI Talent Night: mAI Edition (Frankfurt 2023) · Ribela Festival (Galicia 2024) ·
  SCOPE22 — ratata & Galerie Greulich (Mainz 2022) · Tezos AI Helper (2026).
- "Eigene Plattformen" / "Platforms we built": `grid-template-columns:1fr 1fr; gap:1px;
  background:#26262a; margin:0 40px 36px` (1px gap = hairline grid). Cells `background:#111112;
  padding:16px`: name Archivo 700 19px; year mono 11px `#8a8a86`; body Archivo 14px `#a9a7a1`.
  Items: 8scribo (2022), Tesserart (2024), InfiniteInk (2025), Tezos AI Helper (2026),
  Collective Voice ID (2022–24) — descriptions in the prototype's `dict.platforms`.

### 6. Artist marquee
`border-top`/`border-bottom: 1px solid #111112`, `background:#f6f5f2`, `padding:16px 0`,
`overflow:hidden`. Inner: `flex; gap:40px; width:max-content; white-space:nowrap`,
Archivo **800 26px**, uppercase, `letter-spacing:-0.02em`.
The name string is duplicated twice and animated `translateX(0 → -50%)`, **38s linear infinite**.
Names (` · ` separated): Mario Klingemann, Ivona Tau, Iskra Velitchkova, Tamiko Thiel, Kerim Safa,
Robness, Ruben Fro, Lulu XXX, Anna Malina, Kirk Sora, Oli Sorenson, Salawaki, Theo Horsmeier,
Marissa Noana, mumu_thestan, Merzmensch, HOXID, Luca Martinelli.
Respect `prefers-reduced-motion: reduce` → `animation-play-state: paused`.

### 7. TezCon + Press
`grid-template-columns:1fr 1fr`, each `padding:36px 40px`; left has `border-right:1px solid #111112`.
- **Left**: kicker "Demnächst · 2027" / "Coming up · 2027" mono 11px `#c2410c`;
  "TezCon<br>Europe" Archivo 900 **56px** `line-height:0.95` `letter-spacing:-0.04em`;
  body Archivo 17px `#4a4844` max 44ch; then a mono 11px `#6d6a63` row `gap:24px`:
  `2027` · `FRANKFURT AM MAIN` · `TALKS · SHOW · MUSIC`. Links to `/tezcon-europe`.
- **Right**: kicker "Für Redaktionen" / "For editors"; "Presse" / "Press" 56px;
  then 4 rows `padding:13px 0; border-top:1px solid #dedbd3`, mono 12px, space-between,
  label `#111112` / note `#9b978e`, hover `#c2410c`:
  Pressemappe (PDF) · 2,4 MB — Bildmaterial, druckfähig · ZIP — Logo & Wortmarke · SVG —
  Presseanfragen · info@ratata.gallery.
  (Also **new**. The file sizes are placeholders — print real values, or drop the note column.)

### 8. Partners + footer
- Partners band `padding:30px 40px; border-top:1px solid #111112`: label mono 11px `#9b978e`
  `letter-spacing:0.16em`; logo row `flex-wrap; gap:34px; align-items:center`.
  Logos `height:30px; width:auto; max-width:130px; object-fit:contain; filter:grayscale(1);
  opacity:.55`; hover `filter:none; opacity:1`. Ten logos, from /about.
- Footer `background:#111112`, color `#8a8a86`, `padding:32px 40px`, `flex; justify-content:space-between;
  align-items:flex-end`. Left: wordmark Archivo 900 **44px** `#f6f5f2` + tagline mono 11px
  ("Galerie für digitale Kunst in Frankfurt am Main." / "Gallery for digital art in Frankfurt am Main.").
  Right: mono 11px links `gap:22px`, hover `#ff7a2f`: info@ratata.gallery · INSTAGRAM · X · YOUTUBE ·
  IMPRESSUM · `© 2026`. Keep Datenschutz/Impressum links as on the live site.

---

## Interactions & Behavior
- **DE/EN switch** — swaps every string on the page. Implement with the app's existing i18n
  (locale route or context), not client-side state; the prototype's toggle is a stand-in.
  Active/inactive shown by `opacity: 1 / 0.4`.
- **Hover states** — three patterns, applied consistently:
  1. *Accent* (nav, links, footer, press rows): color → `#c2410c` on light, `#ff7a2f` on dark.
  2. *Inversion* (production rows): light↔dark swap of background/color.
  3. *Zoom* (any artwork thumbnail): `transform: scale(1.04–1.06)`, `transition: transform .5s`.
  Card borders darken to `#111112` on hover.
- **Animations** — only two: the 38s marquee and the 1.4s blinking live dot.
  Both must honour `prefers-reduced-motion`.
- **Focus states** — not designed. Add a visible focus ring (`outline: 2px solid #c2410c;
  outline-offset: 2px`) for keyboard users; the design's borderless, radius-free language means
  a square ring fits.
- **Loading** — artwork images: reserve the aspect ratio and fill with `#e9e6de` (light) /
  `#26262a` (dark) so nothing shifts. SIGNAL: skeleton cards, or hide the section on failure.
- No modals, no forms, no validation in this design. The CTA navigates to the enquiry page.

## State Management
Minimal. Nothing on this page needs client state beyond:
- `locale` — de | en, from routing/i18n.
- `feed` — `{ posts: Post[], mentions: Mention[] }`, fetched server-side and cached.
  `Post = { platform: 'IG'|'X', handle, time, text, imageUrl, permalink }`;
  `Mention = { platform, handle, time, text, permalink }`.
- Everything else (exhibitions, productions, works, partners, counts) is static/CMS content
  resolved at build or request time.

## Design Tokens
**Colors**
| Token | Hex | Use |
|---|---|---|
| paper | `#f6f5f2` | page background (light track) |
| paper-raised | `#ffffff` | matted cards, artwork frames |
| ink | `#111112` | text on light, dark-track background |
| ink-hairline | `#dedbd3` | rules on paper |
| ink-hairline-soft | `#e6e3db` | card borders on paper |
| mat-shadow | `#e2dfd7` | `0 1px 0` under matted cards |
| muted-on-paper | `#6d6a63` | mono meta text on light |
| muted-on-paper-soft | `#9b978e` | timestamps, notes |
| control-border | `#c9c6be` | DE/EN button border |
| thumb-bg | `#e9e6de` | image placeholder on light |
| dark-hairline | `#26262a` | rules on dark |
| dark-hairline-2 | `#35353a` | stronger rules on dark |
| muted-on-dark | `#8a8a86` | mono meta on dark |
| body-on-dark | `#a9a7a1` | paragraph text on dark |
| heading-on-dark | `#d4d2cc` | column heading on dark |
| accent-light | `#c2410c` | accent on paper (hover, kickers) |
| accent-dark | `#ff7a2f` | accent on ink (CTA fill, hover) |
| disclosure | `#ffd9c2` | sample-data chip background |

**Typography** — Archivo (400/500/600/700/800/900) + JetBrains Mono (400/500/700), both Google Fonts.
Self-host in production. Display scale: 104 / 56 / 52 / 44 / 38 / 26 / 22 / 21 / 20 / 19 / 17 / 15 / 14.
Mono scale: 12 / 11.5 / 11 / 10.5 / 10. Display `letter-spacing`: −0.05em at 104/44/26,
−0.04em at 56/52, −0.03em at 38, −0.01em at 22/21/17. Mono tracking: 0.16em kickers,
0.14em nav/labels, 0.12em stats, 0.08–0.1em meta. Body `line-height` 1.4–1.5, display 0.86–1.15.
Paragraphs use `text-wrap: pretty` and `max-width: 44–48ch`.

**Spacing** — 4px base; used steps 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 34, 36, 40, 44, 48.
Section padding `34px 40px 18px` (heading) / `36px 40px` (blocks); page gutter 40px.

**Border radius** — `0` everywhere. Do not round anything.
**Shadows** — one only: `0 1px 0 #e2dfd7` on matted artwork cards.
**Borders** — always `1px`; `#111112` for structural seams, hairline tokens for internal rules.
**Motion** — `transform .5s` (image zoom), `38s linear infinite` (marquee),
`1.4s steps(1) infinite` (live dot).

## Responsive behaviour
Not designed — 1440px desktop only. Intended reductions, to confirm with the designer:
- < 1100px: all `1fr 1fr` two-track grids collapse to one column, art track first, code track after;
  keep the black background as a full-width band so the two-track idea survives as alternating bands.
- < 1100px: hero headline 104px → ~64px, section headings 38px → ~28px, stats strip 5 → 3 columns
  then 2; works grid 3 → 2 columns; SIGNAL posts 2 → 1 column.
- < 720px: gutter 40px → 20px; nav collapses to the existing menu pattern (the live site already has
  a "Menu" affordance); marquee keeps running but at a shorter duration.

## Assets
All imagery in the prototype is **hotlinked from the live site** — replace with the codebase's own
`next/image` pipeline and real records.
- Artworks (from the *What hot Sh!t* project, 2021, Galerie Greulich):
  `https://ratata.gallery/images/what-hot-shit/artworks/` + `deposed-004-poster.jpg`,
  `electric-sheep-5-poster.jpg`, `ambitious-factory-poster.jpg`, `skincare-routine-poster.jpg`,
  `wombat-kiss.gif`, `community.webp`, `sediment-information.webp`, `atlantis-poster.jpg`,
  `feemme-poster.jpg`. Credits in order: Mario Klingemann, Ivona Tau, Kerim Safa, Marissa Noana,
  mumu_thestan, Iskra Velitchkova, Robness, Ruben Fro, Lulu XXX. Each artwork must keep its
  title + artist credit; several are video/GIF works on the real site — poster frames are used here.
- Partner logos: `https://ratata.gallery/images/partners-and-friends/` + `galerie-greulich-logo.png`,
  `tezos-commons-logo.png`, `ai-hub-frankfurt-logo.png`, `theverseverse-logo.png`,
  `teia-cafe-logo.png`, `tesserart-logo.png`, `der-mixer-logo.png`, `tz-apac-logo.svg`,
  `hoxid-logo.png`, `merzmensch.png`.
- **Logo**: not available — the prototype sets the wordmark as Archivo 900 type. Use the real asset.
- Exhibition thumbnails in the prototype reuse artwork images as stand-ins; wire each exhibition to
  its own hero image from the CMS.
- Fonts: Archivo + JetBrains Mono (Google Fonts / SIL OFL).

## Content that is NEW vs. the live site
Flag these with ratata before launch — copy is drafted, not approved:
- "Leistungen / Services" block (3 items).
- "Presse / Press" block (4 rows; file sizes are placeholders).
- Stats strip (numbers derived from the archive; verify 40+ artists and 6 cities).
- "Eigene Plattformen / Platforms we built" grouping.
- SIGNAL social section (entirely new; see feasibility notes).
- Sharpened hero line: "Digitale Kunst braucht echte Wände." / "Digital art needs real walls."
Existing site copy that was kept: tagline, TezCon description, project titles and dates.

## Files
- `Ratata Directions.dc.html` — prototype; **build the `2a` block only**. Content data lives in the
  logic class at the end of the file.
- `support.js` — required to open the prototype locally.
